//Внешние ссылки
$('.part-ss').click(function() {
	window.open($(this).attr('rel'));
});

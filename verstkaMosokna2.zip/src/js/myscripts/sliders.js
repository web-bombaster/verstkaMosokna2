//Слайдер в шапке сайта
// $('.bigslider').slick({
// 	autoplay: true,
// 	autoplaySpeed: 4000,
// 	adaptiveHeight: false,
// 	pauseOnHover: false,
// 	infinite: true,
// 	slidesToShow: 1,
// 	slidesToScroll: 1,
// 	// fade: true,
// 	dots: false
// });

$('.otzyvy-slider').slick({
	// autoplay: true,
	// autoplaySpeed: 4000,
	adaptiveHeight: true,
	// pauseOnHover: false,
	infinite: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	// fade: true,
	dots: false
});

//Слайдер фото в два ряда
// $('.portfolio-slider-photo').slick({
// 	infinite: true,
// 	slidesToShow: 1,
// 	rows: 2,
// 	slidesPerRow: 4,
// 	autoplay: true,
// 	autoplaySpeed: 4000,
// 	fade: true,
// 	dots: false,
// 	responsive: [
// 		{
// 			breakpoint: 1200,
// 			settings: {
// 				slidesPerRow: 4
// 			}
// 		},
// 		{
// 			breakpoint: 700,
// 			settings: {
// 				slidesPerRow: 2
// 			}
// 		},
// 		{
// 			breakpoint: 500,
// 			settings: {
// 				slidesPerRow: 2
// 			}
// 		}
// 		// You can unslick at a given breakpoint now by adding:
// 		// settings: "unslick"
// 		// instead of a settings object
// 	]
// });

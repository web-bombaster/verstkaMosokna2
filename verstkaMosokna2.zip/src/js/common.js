
document.addEventListener(
	"DOMContentLoaded", () => {
		// include './myscripts/preloader.js'
		// include './myscripts/header.js'
		// include './myscripts/mobile-menu.js'
		// include './myscripts/search.js'
		// include './myscripts/burger.js'
		// include './myscripts/tabs.js'
		// include './myscripts/form.js'
		// include './myscripts/accordeon.js'
		// include './myscripts/options.js'
		// include './myscripts/initSwiper.js'
		// -include './myscripts/blazy-init.js'
	}
);
